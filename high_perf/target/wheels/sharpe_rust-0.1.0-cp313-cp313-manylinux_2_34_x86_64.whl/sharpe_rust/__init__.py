from .sharpe_rust import *

__doc__ = sharpe_rust.__doc__
if hasattr(sharpe_rust, "__all__"):
    __all__ = sharpe_rust.__all__